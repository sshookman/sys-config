<#if package?? && package != "">
package ${package};

</#if>
public class ${name} {

}
